from Bag import Bag
from Iterator import Iterator

b = Bag(4)
i = Iterator(b)

b.add(3)
b.add(2)
b.add(5)
b.add(2)

print(i.getCurrent())
i.next()
print(i.getCurrent())
i.next()
print(i.getCurrent())

b.rem(2)
i.first()

print(i.getCurrent())
i.next()
print(i.getCurrent())
i.next()
print(i.getCurrent())

print(b.size())

print(b.search(1))
print(b.search(2))


print(b.nrOccurences(2))


